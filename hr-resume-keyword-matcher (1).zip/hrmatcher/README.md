# HR Resume & Keyword Matcher

A stateless, zero-database B2B resume screening helper designed for Cloudflare Pages + Pages Functions and GitHub deployment.

## Architecture
- `public/`: responsive static web app.
- `functions/api/match.js`: Cloudflare Pages Function API. All matching happens in the request; no resume or job description is persisted.
- No D1, KV, R2, Durable Objects, database, cookies, local storage, analytics, or third-party tracking.
- No AI API key is required. Matching uses transparent lexical/phrase scoring, skill/keyword coverage, and explainable sections.

## Run locally
1. Install Node.js 20+.
2. `npm install`
3. `npm run dev`
4. Open the local URL printed by Wrangler.

## Deploy free on Cloudflare Pages
1. Push this folder to a GitHub repository.
2. In Cloudflare Dashboard, create **Workers & Pages → Create → Pages → Connect to Git**.
3. Select the repository.
4. Framework preset: **None**. Build command: leave blank. Build output directory: `public`.
5. Deploy. Pages Functions in `/functions` are deployed automatically alongside the static site.

Alternative CLI: `npm run deploy` after `npx wrangler login`.

## Privacy and limitations
- Files are read in the browser as text and sent only to the matching endpoint for that request; the endpoint does not write data to storage. The request body exists transiently in memory while processed.
- The included browser extractor supports `.txt` and text-based `.docx` files (DOCX extraction uses the built-in ZIP/XML browser APIs). PDF upload is not included in this dependency-free build; paste resume text or use TXT/DOCX.
- The score is a decision-support signal, not a hiring decision. It does not infer protected traits. Review source material and validate results with a human.
- This is a production-oriented starter, not a substitute for a security, accessibility, legal, and load review before enterprise rollout.

## API
`POST /api/match` JSON body:
```json
{"jobDescription":"...", "resumes":[{"name":"Candidate A","text":"..."}]}
```
Returns aggregate match results and keyword evidence. Inputs are validated and capped; no persistence is performed.
