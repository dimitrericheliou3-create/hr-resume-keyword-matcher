(() => {
  const $ = (s) => document.querySelector(s);
  const job = $('#jobDescription'), jobCount = $('#jobCount'), fileInput = $('#fileInput'), dropzone = $('#dropzone');
  const resumeList = $('#resumeList'), resumeCount = $('#resumeCount'), matchButton = $('#matchButton'), errorMessage = $('#errorMessage');
  let resumes = [], results = [], selectedName = null;
  const MAX_FILES = 50, MAX_TEXT = 100000;
  const escapeHtml = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function toast(message) { const t=$('#toast'); t.textContent=message; t.hidden=false; clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.hidden=true,2600); }
  function showError(message) { errorMessage.textContent=message; errorMessage.hidden=false; errorMessage.scrollIntoView({behavior:'smooth',block:'center'}); }
  function clearError() { errorMessage.hidden=true; errorMessage.textContent=''; }
  job.addEventListener('input',()=>jobCount.textContent=`${job.value.length.toLocaleString()} characters`);
  $('#dismissNotice').addEventListener('click',()=>$('.notice').remove());
  $('#helpBtn').addEventListener('click',()=>$('#helpDialog').showModal());
  $('#closeHelp').addEventListener('click',()=>$('#helpDialog').close());
  $('#gotIt').addEventListener('click',()=>$('#helpDialog').close());
  dropzone.addEventListener('click',()=>fileInput.click());
  dropzone.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();fileInput.click();}});
  fileInput.addEventListener('change',async()=>{await handleFiles([...fileInput.files]);fileInput.value='';});
  ['dragenter','dragover'].forEach(n=>dropzone.addEventListener(n,e=>{e.preventDefault();dropzone.classList.add('dragover');}));
  ['dragleave','drop'].forEach(n=>dropzone.addEventListener(n,e=>{e.preventDefault();dropzone.classList.remove('dragover');}));
  dropzone.addEventListener('drop',e=>handleFiles([...e.dataTransfer.files]));
  async function handleFiles(files) {
    clearError();
    for(const file of files){
      if(resumes.length>=MAX_FILES){showError(`You can add up to ${MAX_FILES} resumes per comparison.`);break;}
      const ext=file.name.split('.').pop().toLowerCase();
      if(!['txt','docx'].includes(ext)){showError(`${file.name}: only TXT and DOCX files are supported.`);continue;}
      try {
        let text;
        if(ext==='txt') text=await file.text(); else text=await extractDocx(file);
        text=text.replace(/\u0000/g,'').trim();
        if(!text){showError(`${file.name}: no readable text found. Try a text-based DOCX or paste the resume manually.`);continue;}
        if(text.length>MAX_TEXT){showError(`${file.name}: extracted text exceeds the 100,000 character limit.`);continue;}
        addResume(file.name.replace(/\.[^.]+$/,''),text,file.name);
      } catch(err){showError(`${file.name}: could not read this file. Try saving it as DOCX or TXT.`);}
    }
    renderResumes();
  }
  async function extractDocx(file){
    // Minimal DOCX reader: read ZIP central directory and extract word/document.xml with browser APIs.
    const bytes=new Uint8Array(await file.arrayBuffer());
    const view=new DataView(bytes.buffer); let eocd=-1;
    for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65558);i--){if(view.getUint32(i,true)===0x06054b50){eocd=i;break;}}
    if(eocd<0)throw new Error('Invalid DOCX archive');
    const count=view.getUint16(eocd+10,true), centralOffset=view.getUint32(eocd+16,true); let p=centralOffset;
    for(let n=0;n<count;n++){
      if(view.getUint32(p,true)!==0x02014b50)throw new Error('Invalid ZIP directory');
      const method=view.getUint16(p+10,true), compressedSize=view.getUint32(p+20,true), nameLen=view.getUint16(p+28,true), extraLen=view.getUint16(p+30,true), commentLen=view.getUint16(p+32,true), localOffset=view.getUint32(p+42,true);
      const name=new TextDecoder().decode(bytes.slice(p+46,p+46+nameLen));
      if(name==='word/document.xml'){
        if(view.getUint32(localOffset,true)!==0x04034b50)throw new Error('Invalid ZIP entry');
        const ln=view.getUint16(localOffset+26,true), le=view.getUint16(localOffset+28,true), start=localOffset+30+ln+le;
        const packed=bytes.slice(start,start+compressedSize); let xmlBytes;
        if(method===0)xmlBytes=packed;
        else if(method===8){if(typeof DecompressionStream==='undefined')throw new Error('Deflate not supported');const ds=new DecompressionStream('deflate-raw');const stream=new Blob([packed]).stream().pipeThrough(ds);xmlBytes=new Uint8Array(await new Response(stream).arrayBuffer());}
        else throw new Error('Unsupported compression');
        const xml=new TextDecoder().decode(xmlBytes), doc=new DOMParser().parseFromString(xml,'application/xml');
        if(doc.querySelector('parsererror'))throw new Error('Invalid document XML');
        return [...doc.getElementsByTagNameNS('*','p')].map(p=>[...p.getElementsByTagNameNS('*','t')].map(t=>t.textContent).join('')).join('\n');
      }
      p+=46+nameLen+extraLen+commentLen;
    }
    throw new Error('Missing document text');
  }
  function addResume(name,text,source=name){if(resumes.length>=MAX_FILES)return;resumes.push({id:crypto.randomUUID?crypto.randomUUID():`${Date.now()}-${Math.random()}`,name:String(name).slice(0,120),text,source});renderResumes();}
  function renderResumes(){resumeCount.textContent=resumes.length; if(!resumes.length){resumeList.innerHTML='<div class="empty-resumes"><span>▧</span><p>No resumes added yet</p><small>Upload files or paste candidate text below.</small></div>';return;}resumeList.innerHTML=resumes.map(r=>`<div class="resume-item"><div class="file-icon">${r.source.toLowerCase().endsWith('.docx')?'DOC':'TXT'}</div><div class="resume-meta"><b title="${escapeHtml(r.name)}">${escapeHtml(r.name)}</b><small>${r.text.length.toLocaleString()} characters · ready to compare</small></div><button class="remove-resume" type="button" data-remove="${escapeHtml(r.id)}" aria-label="Remove ${escapeHtml(r.name)}">×</button></div>`).join('');}
  resumeList.addEventListener('click',e=>{const b=e.target.closest('[data-remove]');if(!b)return;resumes=resumes.filter(r=>r.id!==b.dataset.remove);renderResumes();});
  $('#addCandidate').addEventListener('click',()=>{clearError();const name=$('#candidateName').value.trim()||`Candidate ${String(resumes.length+1).padStart(2,'0')}`,text=$('#candidateText').value.trim();if(!text){showError('Paste resume text before adding the candidate.');return;}if(resumes.length>=MAX_FILES){showError(`You can add up to ${MAX_FILES} resumes.`);return;}if(text.length>MAX_TEXT){showError('Resume text must be 100,000 characters or fewer.');return;}addResume(name,text,'pasted.txt');$('#candidateName').value='';$('#candidateText').value='';toast('Candidate added');});
  $('#clearResumes').addEventListener('click',()=>{resumes=[];renderResumes();clearError();$('#resultsSection').hidden=true;results=[];toast('All resumes cleared');});
  matchButton.addEventListener('click',async()=>{
    clearError();const jobDescription=job.value.trim();if(jobDescription.length<30){showError('Add a job description with at least 30 characters.');job.focus();return;}if(!resumes.length){showError('Add at least one resume before matching.');return;}
    matchButton.disabled=true;matchButton.innerHTML='<span class="spinner">◌</span> Matching…';
    try{const res=await fetch('/api/match',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jobDescription,resumes:resumes.map(r=>({name:r.name,text:r.text}))})});const data=await res.json();if(!res.ok)throw new Error(data.error||'Could not match resumes.');results=data.results;selectedName=null;renderResults(data);$('#resultsSection').hidden=false;$('#resultsSection').scrollIntoView({behavior:'smooth',block:'start'});}
    catch(e){showError(e.message||'Something went wrong. Please try again.');}
    finally{matchButton.disabled=false;matchButton.innerHTML='<span>✳</span> Match resumes <span class="button-arrow">→</span>';}
  });
  function renderResults(data){const avg=results.length?Math.round(results.reduce((s,r)=>s+r.score,0)/results.length):0, strong=results.filter(r=>r.score>=75).length;$('#metricsGrid').innerHTML=`<article class="metric-card"><span class="metric-mark">◉</span><small>Resumes compared</small><strong>${results.length}</strong><p>Candidate profiles processed</p></article><article class="metric-card"><span class="metric-mark">✳</span><small>Average keyword match</small><strong>${avg}%</strong><p>Across all resumes in this run</p></article><article class="metric-card"><span class="metric-mark">✓</span><small>Strong keyword alignment</small><strong>${strong}</strong><p>Resumes with 75%+ keyword overlap</p></article>`;renderTable();}
  function renderTable(){let list=[...results];if($('#sortSelect').value==='name')list.sort((a,b)=>a.name.localeCompare(b.name));else list.sort((a,b)=>b.score-a.score);$('#resultsBody').innerHTML=list.map((r,i)=>{const state=r.score>=75?'strong':r.score>=50?'partial':'low',label=r.score>=75?'Strong alignment':r.score>=50?'Partial alignment':'Low alignment';return `<tr><td>${escapeHtml(r.name)}</td><td><div class="score-cell"><span class="score-number">${r.score}%</span><span class="score-track"><span class="score-fill" style="display:block;width:${r.score}%"></span></span></div></td><td>${r.matchedCount} / ${r.totalKeywords}</td><td>${r.skillCoverage}%</td><td><span class="pill ${state}">${label}</span></td><td><button class="view-button" data-view="${escapeHtml(r.name)}" type="button">Review details ↗</button></td></tr>`;}).join('');if(selectedName)showDetails(selectedName);else $('#candidateDetail').hidden=true;}
  $('#sortSelect').addEventListener('change',renderTable);
  $('#resultsBody').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(!b)return;selectedName=b.dataset.view;showDetails(selectedName);});
  function showDetails(name){const r=results.find(x=>x.name===name);if(!r)return;const detail=$('#candidateDetail');detail.hidden=false;detail.innerHTML=`<div class="detail-title"><h4>Keyword evidence: ${escapeHtml(r.name)}</h4><button type="button" id="closeDetail" aria-label="Close details">×</button></div><p style="font-size:10px;color:#8793a7;line-height:1.6">${escapeHtml(r.note)}</p><div class="detail-grid"><div><h5>Matched terms (${r.matchedKeywords.length})</h5><div class="keyword-list">${r.matchedKeywords.length?r.matchedKeywords.map(k=>`<span class="keyword-tag">${escapeHtml(k)}</span>`).join(''):'<span class="detail-empty">No matching terms found.</span>'}</div></div><div><h5>Terms to verify / missing (${r.missingKeywords.length})</h5><div class="keyword-list">${r.missingKeywords.length?r.missingKeywords.map(k=>`<span class="keyword-tag missing">${escapeHtml(k)}</span>`).join(''):'<span class="detail-empty">No missing terms in the extracted list.</span>'}</div></div><div><h5>Common skills matched (${r.matchedSkills.length})</h5><div class="keyword-list">${r.matchedSkills.length?r.matchedSkills.map(k=>`<span class="keyword-tag">${escapeHtml(k)}</span>`).join(''):'<span class="detail-empty">No curated skills matched.</span>'}</div></div><div><h5>Common skills not found (${r.missingSkills.length})</h5><div class="keyword-list">${r.missingSkills.length?r.missingSkills.map(k=>`<span class="keyword-tag missing">${escapeHtml(k)}</span>`).join(''):'<span class="detail-empty">All detected job skills were found.</span>'}</div></div></div>`;$('#closeDetail').addEventListener('click',()=>{detail.hidden=true;selectedName=null;});detail.scrollIntoView({behavior:'smooth',block:'nearest'});}
  $('#exportCsv').addEventListener('click',()=>{if(!results.length)return;const cells=[['Candidate','Match score','Keywords matched','Total keywords','Skill coverage','Alignment','Matched keywords','Missing keywords'],...results.map(r=>[r.name,`${r.score}%`,r.matchedCount,r.totalKeywords,`${r.skillCoverage}%`,r.summary,r.matchedKeywords.join('; '),r.missingKeywords.join('; ')])];const csv=cells.map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\r\n');const blob=new Blob(['\ufeff',csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='resume-match-results.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('CSV exported');});
  renderResumes();
})();
